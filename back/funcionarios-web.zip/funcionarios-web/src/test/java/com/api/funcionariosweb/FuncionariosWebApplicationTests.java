package com.api.funcionariosweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuncionariosWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
